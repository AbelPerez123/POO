<?php
include_once('../models/conexion.php');
include_once('../models/funciones.php');
include_once('./funciones.php');

if(isset($_POST['usuario']) && isset($_POST['password'])){
    $user = $_POST['usuario'];
    $pass = $_POST['password'];
    $tabla = "usuarios";
    $campo = "usuario";
    AL($user,$pass,$tabla,$campo);
} else{
    header("Location: ../index.php");
}